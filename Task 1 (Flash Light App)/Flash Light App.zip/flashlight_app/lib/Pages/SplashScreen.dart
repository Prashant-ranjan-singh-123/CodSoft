import 'package:Flashlight/Pages/FlashLight.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';


class SplashScreen extends StatefulWidget {
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 4), (){
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> FlashLight()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Lottie.asset('Resource/Lottie/Flashlight.json', reverse: true),
              const Text("Flashlight By Prashant Singh", style: TextStyle(
                  color: Colors.white,
                fontWeight: FontWeight.bold,
                fontFamily: 'Caveat',
                fontSize: 20.0
              ),
              )
            ],
          )
        ),
      ),
    );
  }
}
