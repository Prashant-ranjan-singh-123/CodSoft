import 'package:flutter/material.dart';
import 'package:torch_light/torch_light.dart';
import 'package:permission_handler/permission_handler.dart';

class FlashLight extends StatefulWidget {
  const FlashLight({Key? key}) : super(key: key);

  @override
  State<FlashLight> createState() => _FlashLightState();
}

class _FlashLightState extends State<FlashLight> {
  late bool isFlashOn;
  var button=1;
  @override
  void initState() {
    isFlashOn=false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: Color.fromRGBO(31, 29, 14, 1),
        child: Center(
          child: GestureDetector(
            child: Image.asset('Resource/Images/$button.png'),
            onTap: () async{
              if(!isFlashOn) {
                try {
                  await TorchLight.enableTorch();
                  isFlashOn=true;
                  button=2;
                } on Exception catch (_) {
                  final status = Permission.camera.request();
                  if(await status.isDenied){
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Permission Denied")));
                  }
                }
                setState(() {});
              }else {
                try {
                  await TorchLight.disableTorch();
                  isFlashOn=false;
                  button=1;
                } on Exception catch (_) {
                  final status = Permission.camera.request();
                  if(await status.isDenied){
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Permission Denied")));
                  }
                }
                setState(() {});
              }
            },
          )
        ),
      ),
    );
  }
}
